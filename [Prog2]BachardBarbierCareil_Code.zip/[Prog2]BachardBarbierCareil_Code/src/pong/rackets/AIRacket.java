package pong.rackets;

import javafx.beans.property.DoubleProperty;
import pong.core.Ball;
import pong.core.Engine;
import pong.core.Racket;
import pong.core.RacketSide;

import static com.sun.javafx.util.Utils.clamp;
import static java.lang.Math.abs;

/**
 * AI racket
 */
public class AIRacket extends Racket
{
    private final DoubleProperty ballY;

    public AIRacket(Engine engine, Ball ball, RacketSide side, double speed)
    {
        super(engine, side, speed);

        this.ballY = ball.positionYProperty();
    }

    @Override
    protected double nextY()
    {
        double sign = (ballY.getValue() + getRacketHeight() / 2 - getRacketY()) / abs(ballY.getValue() + getRacketHeight() / 2 - getRacketY());
        return getRacketY() + sign * getSpeed() * clamp(abs((ballY.getValue() + getRacketHeight() / 2 - getRacketY()) / getSpeed()), 0, 0.1);
    }
}
