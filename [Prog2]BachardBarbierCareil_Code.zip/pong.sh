cd out
java pong.Main
