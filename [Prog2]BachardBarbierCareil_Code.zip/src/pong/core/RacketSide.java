package pong.core;

public enum RacketSide
{
    LEFT,
    RIGHT
}
